package com.example.logindemo;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.function.BinaryOperator;

public class WorkFragment extends Fragment {
    private Button button;
    Date result;
    double ResultNum;
    TextView StartTime2;
    TextView EndTime2;
    TextView AntwTijd;
    Date StartDate;
    Date EndDate;
    Button BtnTijd;
    int hour,min;

    private WorkViewmodel viewmodel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_work,container, false);
        viewmodel= ViewModelProviders.of(requireActivity()).get(WorkViewmodel.class);

        button =(Button) view.findViewById(R.id.button);
        StartTime2=view.findViewById(R.id.startTime);
        EndTime2=view.findViewById(R.id.endTime);
        BtnTijd=view.findViewById(R.id.btnTijd);
        AntwTijd=view.findViewById(R.id.antwTijd);
        Calendar mCurrentTime = Calendar.getInstance();
        hour = mCurrentTime.get(Calendar.HOUR_OF_DAY);
        min = mCurrentTime.get(Calendar.MINUTE);
        EndTime2.setOnClickListener(view1 -> showTime(hour,min,view1));
        StartTime2.setOnClickListener(view1 -> showTime(hour,min, view1));
        BtnTijd.setOnClickListener(view1 -> {
            TimeZone tz=Calendar.getInstance().getTimeZone();
            long diff= viewmodel.getEndDate().getValue().getTime()-viewmodel.getStartDate().getValue().getTime();
            //ResultNum= (double) diff / 3600000;
            viewmodel.getDiff().setValue((double) diff / 3600000);

            diff-=tz.getOffset(diff);
            result=new Date(diff);
            //SimpleDateFormat sdf=new SimpleDateFormat("HH"+"\n"+"mm");
            //AntwTijd.setText(sdf.format(result));
            viewmodel.getDiffDate().setValue(result);
        });
        final Observer<Date> startDate= new Observer<Date>() {
            @Override
            public void onChanged(Date startDate) {
                SimpleDateFormat sdf=new SimpleDateFormat("HH"+"\n"+"mm");
                StartTime2.setText(sdf.format(startDate));
            }
        };
        viewmodel.getStartDate().observe(requireActivity(),startDate);
        final Observer<Date> endDate= new Observer<Date>() {
            @Override
            public void onChanged(Date endDate) {
                SimpleDateFormat sdf=new SimpleDateFormat("HH"+"\n"+"mm");
                EndTime2.setText(sdf.format(endDate));
            }
        };
        viewmodel.getEndDate().observe(requireActivity(),endDate);
        final Observer<Date> diffDate= new Observer<Date>() {
            @Override
            public void onChanged(Date diffDate) {
                SimpleDateFormat sdf=new SimpleDateFormat("HH"+"\n"+"mm");
                AntwTijd.setText(sdf.format(diffDate));
            }
        };
        viewmodel.getDiffDate().observe(requireActivity(),diffDate);
        final Observer<Double> diffDouble= new Observer<Double>() {
            @Override
            public void onChanged(Double diff) {
                ResultNum=diff;
            }
        };
        viewmodel.getDiff().observe(requireActivity(),diffDouble);
        final Observer<Boolean> btnTijd= new Observer<Boolean>() {
            @Override
            public void onChanged(Boolean button) {
                BtnTijd.setEnabled(button);
            }
        };
        viewmodel.getIsButtonEnabled().observe(requireActivity(),btnTijd);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity(), CalculatorActivity.class);
                intent.putExtra("some_key", ResultNum);
                startActivity(intent);
            }
        });
        /*if(savedInstanceState!=null)
        {
            BtnTijd.setEnabled(savedInstanceState.getBoolean(STATE_BUTTON_ENABLED,false));
            StartDate = new Date(savedInstanceState.getLong(STATE_START_DATE));
            EndDate = new Date(savedInstanceState.getLong(STATE_END_DATE));
            AntwTijd.setText(savedInstanceState.getString(STATE_VERSCHIL, ""));
            ResultNum= savedInstanceState.getDouble(STATE_VERSCHIL_KANTEL);
        }*/




        /*result=(TextView) view.findViewById(R.id.txtUur);
        StartTime=(EditText) view.findViewById(R.id.StartTime);
        EndTime=(EditText) view.findViewById(R.id.EndTime);
        Bereken=(Button) view.findViewById(R.id.btnCalc);


        Bereken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                num1=Integer.parseInt(StartTime.getText().toString());
                num2=Integer.parseInt(EndTime.getText().toString());
                if(num1>24||num2>24){
                    result.setText("max waarde is 24");
                }
                else if(num2>num1){

                    ResultNum=num2-num1;
                    result.setText(String.valueOf(ResultNum)+" uur");
                }
                else if(num2<num1){
                    result.setText("Eindwaarde kan niet kleiner zijn dan startwaarde!");
                }
                else if(num2==num1){
                    result.setText("0 uur");
                }

            }
        });*/
        return view;
    }
    void showTime(int hours,  int minte, View view) {
        TextView textView;
        if(view instanceof TextView){
            textView=(TextView) view;
            TimePickerDialog mTimePicker;
            mTimePicker = new TimePickerDialog(requireActivity(), new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {

                    hour = selectedHour;
                    min = selectedMinute;
                    Calendar newTime=Calendar.getInstance();
                    newTime.set(Calendar.SECOND,0);
                    newTime.set(Calendar.MILLISECOND,0);
                    newTime.set(Calendar.HOUR_OF_DAY,selectedHour);
                    newTime.set(Calendar.MINUTE,selectedMinute);
                    SimpleDateFormat sdf=new SimpleDateFormat("HH:mm");
                    textView.setText(sdf.format(newTime.getTime()));
                    if(textView.getId()==R.id.startTime){
                        viewmodel.getStartDate().setValue(newTime.getTime());
                    }
                    else{
                        viewmodel.getEndDate().setValue(newTime.getTime());
                    }
                    if(viewmodel.getEndDate().getValue()!=null&&viewmodel.getStartDate().getValue()!=null){

                        viewmodel.getIsButtonEnabled().setValue(viewmodel.getEndDate().getValue().getTime() > viewmodel.getStartDate().getValue().getTime());
                    }

                }
            }, hours, minte, false);//Yes 24 hour time
            mTimePicker.setTitle("Select Time");
            mTimePicker.show();
        }

    }
    static final String  STATE_BUTTON_ENABLED= "buttonEnabled";
    static final String  STATE_START_DATE= "startDate";
    static final String  STATE_END_DATE= "endDate";
    static final String  STATE_VERSCHIL= "tijdVerschil";
    static final String  STATE_VERSCHIL_KANTEL= "tijdVerschilNaKantel";

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        if(StartDate!=null){
            savedInstanceState.putLong(STATE_START_DATE, StartDate.getTime());
        }
        if(EndDate!=null){
            savedInstanceState.putLong(STATE_END_DATE, EndDate.getTime());
        }
        if(AntwTijd!=null){
            savedInstanceState.putString(STATE_VERSCHIL,AntwTijd.getText().toString());
        }
        if(ResultNum != 0){
            savedInstanceState.putDouble(STATE_VERSCHIL_KANTEL,ResultNum);
        }
        savedInstanceState.putBoolean(STATE_BUTTON_ENABLED,BtnTijd.isEnabled());
        super.onSaveInstanceState(savedInstanceState);
        /*savedInstanceState.putLong(STATE_START_DATE,StartDate.getTime());
        savedInstanceState.putLong(STATE_END_DATE,EndDate.getTime());*/
    }


}
